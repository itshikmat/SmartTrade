# SmartTrade Tokenomics

- **Total Supply**: 1,000,000,000 STRD
- **Transaction Fee**: 0.5% (used for staking rewards and development)
- **Staking Rewards**: Users earn STRD by staking on the platform.

## Token Allocation
- 50% - Community & Rewards
- 20% - Development Fund
- 15% - Team & Advisors
- 10% - Marketing
- 5% - Reserve
