# Code of Conduct
All participants in the SmartTrade community are expected to uphold a respectful, inclusive, and professional environment.

### Unacceptable Behavior
- Harassment, discrimination, or hate speech.
- Spamming or disruptive behavior.

Violators will be banned from the project.
