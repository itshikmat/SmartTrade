# Feature Request
**Is your feature request related to a problem?**
Please describe.

**Describe the solution you'd like**
Explain how this feature will improve SmartTrade.
